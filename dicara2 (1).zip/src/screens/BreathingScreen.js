import React from 'react';
import { View, Text, Button } from 'react-native';
import BreathingAnimation from '../components/BreathingAnimation';

const BreathingScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Técnica 4-7-8</Text>
      <BreathingAnimation />
      <Button title="Iniciar" onPress={() => {}} />
    </View>
  );
};

export default BreathingScreen;
