import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const GroundingScreen = () => {
  const [step, setStep] = useState(0);
  const steps = [
    { text: "5 coisas que você vê", color: '#2B3A55' },
    { text: "4 coisas que você sente", color: '#A3E4D7' },
    { text: "3 coisas que você ouve", color: '#2B3A55' },
    { text: "2 coisas que você cheira", color: '#A3E4D7' },
    { text: "1 coisa que você prova", color: '#2B3A55' },
  ];

  return (
    <View style={styles.container}>
      <Text style={[styles.stepText, { color: steps[step].color }]}>
        {steps[step].text}
      </Text>
      {step < steps.length - 1 && (
        <Button title="Próximo" onPress={() => setStep(step + 1)} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  stepText: { fontSize: 24, textAlign: 'center', margin: 20 },
});

export default GroundingScreen;
