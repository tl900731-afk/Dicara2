import React from 'react';
import { View, Button } from 'react-native';
import * as SMS from 'expo-sms';

const EmergencyScreen = () => {
  const handlePanicButton = async () => {
    await SMS.sendSMSAsync(
      ['+5511999999999'],
      'Preciso de apoio agora. Minha localização: [link do GPS]'
    );
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Button title="Botão de Pânico" onPress={handlePanicButton} />
    </View>
  );
};

export default EmergencyScreen;
