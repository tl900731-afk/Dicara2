import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import BreathingScreen from '../screens/BreathingScreen';
import GroundingScreen from '../screens/GroundingScreen';
import EmergencyScreen from '../screens/EmergencyScreen';
import { View, Text } from 'react-native';

const Tab = createBottomTabNavigator();

const HomeScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 22 }}>Bem-vindo ao DI CARA</Text>
  </View>
);

const TabNavigation = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let icon;
          if (route.name === 'Home') icon = 'home';
          if (route.name === 'Respiração') icon = 'lungs';
          if (route.name === 'Emergência') icon = 'alert-circle';
          if (route.name === 'Grounding') icon = 'meditation';
          return <MaterialCommunityIcons name={icon} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Respiração" component={BreathingScreen} />
      <Tab.Screen name="Grounding" component={GroundingScreen} />
      <Tab.Screen name="Emergência" component={EmergencyScreen} />
    </Tab.Navigator>
  );
};

export default TabNavigation;
